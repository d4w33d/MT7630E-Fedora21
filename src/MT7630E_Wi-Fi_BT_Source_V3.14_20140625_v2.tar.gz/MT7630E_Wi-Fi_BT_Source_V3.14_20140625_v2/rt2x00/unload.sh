rmmod rt2800pci.ko;
rmmod rt2800lib.ko;
rmmod rt2x00mmio.ko;
rmmod rt2x00pci.ko;
rmmod rt2x00lib.ko;
